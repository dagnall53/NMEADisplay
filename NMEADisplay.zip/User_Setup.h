//                            TFT_espi USER DEFINED SETTINGS
// TIt is necessary to modify the User_Setup_Select.h in the library for every different display

// Modified User_Setup_Select.h to exclude #include <User_Setup.h>  in case it conflicts.. 
//Unfortunately no way to send this compile to the library/. 

//DAG select correct driver in my library path 
//  #include <User_Setups/Setup25_TTGO_T_Display.h>    // Setup file for ESP32 and TTGO T-Display ST7789V SPI bus TFT

