#ifndef _SINECOS_H_
#define _SINECOS_H_
//#include <Arduino_GFX_Library.h>
#include <Arduino.h>


// helpers for sine cos?

int getSine(int angle);
int getCosine(int angle);

#endif